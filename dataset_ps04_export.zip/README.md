# PS-04 Autonomous Customer Support System - Dataset Archive

This archive contains the standalone mock dataset, knowledge base documents, and enterprise policies for the Autonomous Agentic Customer Support System (PS-04).

## File Structure

- customers.json / customers.csv: 5 customer persona records (VIP, Premium, Standard tiers).
- products.json / products.csv: Product catalog items with prices, stock, and categories.
- orders.json / orders.csv: 6 e-commerce orders across various statuses (processing, shipped, delivered, payment_failed).
- payments.json / payments.csv: Payment transaction logs and settlement statuses.
- 	ickets.json / 	ickets.csv: Escalated support tickets with assigned departments and SLA targets.
- csat_ratings.json: Customer satisfaction ratings and review feedback.
- knowledge_base_articles.json: 22 enterprise policy articles and troubleshooting knowledge base entries.
- python_source/: Original backend Python definitions (mock_data.py, knowledge_base.py, policy_rules.py).

## Notes
- All records are fictional mock data designed for demonstration, benchmarking, and academic evaluation.
- No live production databases or credentials were used.
